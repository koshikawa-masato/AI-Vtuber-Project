#!/bin/bash

# GPU Ollama Server for Mouth (口) LLM
# This server runs qwen2.5:14b on GPU for fast realtime conversation
# Port: 11434 (default Ollama port)

echo "Starting GPU Ollama server on port 11434..."
echo "This server will run qwen2.5:14b on GPU for realtime chat"

# GPU execution (default - no CUDA_VISIBLE_DEVICES restriction)
# Use GPU 0
export CUDA_VISIBLE_DEVICES=0

# Share model storage with system Ollama (read-only access)
# System models are in /usr/share/ollama/.ollama/models
# User models in $HOME/.ollama/models (fallback)
export OLLAMA_MODELS=$HOME/.ollama/models

# Start Ollama server on port 11434 (default)
OLLAMA_HOST=0.0.0.0:11434 ollama serve
