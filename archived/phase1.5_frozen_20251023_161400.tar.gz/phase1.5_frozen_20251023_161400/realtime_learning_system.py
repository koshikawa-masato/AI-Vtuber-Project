"""Realtime Learning System - Phase 1.5
リアルタイム学習システム: 会話ごとの非同期分析

【二重構造】
- 口（即時LLM）: GPU 14b で即座に応答（1.5秒）
- 頭脳（長考LLM）: CPU 32b で深い分析（60-120秒、バックグラウンド）

【完全ローカル実行】
- すべてローカルPC（Ryzen 9 9950X）で実行
- VPS不要、魂を外部に出さない
"""

import asyncio
import json
import os
import time
import requests
from typing import Dict, Any, List
from pathlib import Path
from datetime import datetime


class RealtimeLearningSystem:
    """
    リアルタイム学習システム
    - 会話ごとに非同期で32b分析
    - GPUの即時応答を妨げない
    - 常に考え続ける（バックグラウンド分析）
    """

    def __init__(
        self,
        relationship_manager,
        session_manager,
        user_profile_path: Path = Path("user_profile.json"),
        context_path: Path = Path("context_for_satsuru.json"),
        idle_thinking_interval: int = 300  # 5 minutes default
    ):
        self.relationship_manager = relationship_manager
        self.session_manager = session_manager
        self.user_profile_path = user_profile_path
        self.context_path = context_path
        self.idle_thinking_interval = idle_thinking_interval

        # User profile
        self.user_profile = self._load_user_profile()

        # Context for satsuru
        self.context_for_satsuru = self._load_context()

        # Background analysis tasks
        self.background_tasks: List[asyncio.Task] = []

        # Idle thinking control
        self.idle_thinking_task: asyncio.Task = None
        self.is_in_conversation: bool = False
        self.last_conversation_time: float = time.time()

        # Session time tracking
        self.session_start_time: float = time.time()
        self.last_session_end_time: float = self._load_last_session_time()

    def _load_user_profile(self) -> Dict[str, Any]:
        """Load user profile from JSON"""
        if self.user_profile_path.exists():
            try:
                with open(self.user_profile_path, "r", encoding="utf-8") as f:
                    profile = json.load(f)
                print(f"[USER_PROFILE] Loaded: {len(profile)} entries")
                return profile
            except Exception as e:
                print(f"[USER_PROFILE ERROR] Failed to load: {e}")
                return {}
        else:
            print("[USER_PROFILE] No existing profile, initializing")
            return {}

    def _save_user_profile(self):
        """Save user profile to JSON"""
        try:
            with open(self.user_profile_path, "w", encoding="utf-8") as f:
                json.dump(self.user_profile, f, ensure_ascii=False, indent=2)
            print(f"[USER_PROFILE] Saved: {len(self.user_profile)} entries")
        except Exception as e:
            print(f"[USER_PROFILE ERROR] Failed to save: {e}")

    def _load_context(self) -> Dict[str, Any]:
        """Load context for satsuru from JSON"""
        if self.context_path.exists():
            try:
                with open(self.context_path, "r", encoding="utf-8") as f:
                    context = json.load(f)
                print(f"[CONTEXT] Loaded")
                return context
            except Exception as e:
                print(f"[CONTEXT ERROR] Failed to load: {e}")
                return {}
        else:
            print("[CONTEXT] No existing context, initializing")
            return {}

    def _save_context(self):
        """Save context for satsuru to JSON"""
        try:
            with open(self.context_path, "w", encoding="utf-8") as f:
                json.dump(self.context_for_satsuru, f, ensure_ascii=False, indent=2)
            print(f"[CONTEXT] Saved")
        except Exception as e:
            print(f"[CONTEXT ERROR] Failed to save: {e}")

    async def immediate_response_gpu(
        self,
        user_message: str,
        chat_history: List[Dict[str, str]]
    ) -> str:
        """
        即座に応答（GPU版14b）
        - 1.5秒以内に応答
        - ユーザー体験を妨げない
        """
        # Use Ollama HTTP API with GPU (default, no CUDA_VISIBLE_DEVICES override)
        try:
            start = time.time()

            # Prepare messages
            messages = chat_history + [{"role": "user", "content": user_message}]

            # Call Ollama HTTP API (GPU default)
            response = await asyncio.to_thread(
                requests.post,
                "http://localhost:11434/api/chat",
                json={
                    "model": "qwen2.5:14b",
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": 0.7
                    }
                },
                timeout=30
            )

            elapsed = time.time() - start

            if response.status_code == 200:
                # Parse response
                result = response.json()
                botan_reply = result.get("message", {}).get("content", "")

                print(f"[GPU 14b] Response in {elapsed:.2f}s: '{botan_reply[:50]}...'")

                # Trigger background analysis (non-blocking)
                asyncio.create_task(
                    self.background_analysis_cpu(user_message, botan_reply, chat_history)
                )

                return botan_reply
            else:
                print(f"[GPU 14b ERROR] Ollama HTTP failed: {response.status_code}")
                return "ごめん、ちょっと調子悪いかも..."

        except Exception as e:
            print(f"[GPU 14b ERROR] {e}")
            return "え〜、なんか固まっちゃった...ごめん！"

    async def background_analysis_cpu(
        self,
        user_message: str,
        botan_reply: str,
        chat_history: List[Dict[str, str]]
    ):
        """
        会話直後に非同期で分析開始（60-120秒、並行実行）
        - GPU応答を妨げない
        - 複数の分析が並行実行可能（Ryzen 9 9950X: 3-4並行）
        - 即座にJSON更新

        Note: Requires CPU-only Ollama server running on port 11435
        Start with: ./start_cpu_ollama_server.sh
        """
        # Update last conversation time (important for idle thinking)
        self.last_conversation_time = time.time()
        self.is_in_conversation = True

        print(f"[CPU 32b] Starting background analysis...")

        try:
            start = time.time()

            # Prepare analysis prompt
            analysis_prompt = self._generate_analysis_prompt(
                user_message, botan_reply, chat_history
            )

            # Call CPU-only Ollama HTTP API on port 11435
            response = await asyncio.to_thread(
                requests.post,
                "http://localhost:11435/api/chat",
                json={
                    "model": "qwen2.5:32b",
                    "messages": [
                        {"role": "user", "content": analysis_prompt}
                    ],
                    "stream": False,
                    "options": {
                        "temperature": 0.3  # Lower temperature for analytical task
                    }
                },
                timeout=180  # 3 minutes max
            )

            elapsed = time.time() - start

            if response.status_code == 200:
                # Parse analysis result
                result = response.json()
                llm_output = result.get("message", {}).get("content", "")

                analysis = self._parse_analysis(llm_output)

                # Apply updates immediately
                await self._apply_updates(analysis)

                print(f"[CPU 32b] Analysis completed in {elapsed:.2f}s")
            else:
                print(f"[CPU 32b ERROR] Ollama HTTP failed: {response.status_code}")

        except Exception as e:
            print(f"[CPU 32b ERROR] {e}")
            import traceback
            traceback.print_exc()

    def _generate_analysis_prompt(
        self,
        user_message: str,
        botan_reply: str,
        chat_history: List[Dict[str, str]]
    ) -> str:
        """Generate analysis prompt for 32b LLM"""
        return f"""
Analyze this conversation deeply and extract insights:

User: {user_message}
Botan: {botan_reply}

Previous conversation context:
{self._format_chat_history(chat_history[-5:])}

Extract the following in JSON format:

1. user_profile_updates:
   - food_preferences: List of foods User mentioned (e.g., ["sushi", "ramen"])
   - hobbies: List of hobbies/interests
   - habits: Morning/night person, work patterns, etc.
   - personality_traits: Patient, kind, stressed, etc.
   - communication_style: Prefers empathy/advice/brevity

2. relationship_changes:
   - affection_delta: +0 to +3 (increase in affection)
   - trust_delta: +0 to +2
   - intimacy_delta: +0 to +2
   - respect_delta: +0 to +2
   - reasoning: Explain why each changed

3. context_for_satsuru:
   - user_emotional_state: happy/stressed/tired/frustrated/neutral
   - likely_needs: ["empathy", "advice", "rest", "venting", "practical_help"]
   - recommended_style: "open_question" / "caring_suggestion" / "shared_feeling" / "light_reply"
   - avoid: ["long_explanations", "unsolicited_advice", "showing_off_knowledge"]

4. emotional_state:
   - botan_feeling: Botan's emotion during this conversation
   - relationship_dynamic: How the relationship changed
   - anticipation: Looking forward to next conversation?

Return ONLY valid JSON, no extra text:
{{
  "user_profile_updates": {{}},
  "relationship_changes": {{}},
  "context_for_satsuru": {{}},
  "emotional_state": {{}}
}}
"""

    def _format_chat_history(self, history: List[Dict[str, str]]) -> str:
        """Format chat history for display"""
        formatted = []
        for msg in history:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if role == "user":
                formatted.append(f"User: {content}")
            elif role == "assistant":
                formatted.append(f"Botan: {content}")
        return "\n".join(formatted)

    def _parse_analysis(self, llm_output: str) -> Dict[str, Any]:
        """Parse 32b LLM output (JSON format)"""
        try:
            # Extract JSON from output
            analysis = json.loads(llm_output)
            return analysis
        except json.JSONDecodeError as e:
            print(f"[PARSE ERROR] Failed to parse LLM output as JSON: {e}")
            print(f"[PARSE ERROR] Output was: {llm_output[:500]}")
            return {
                "user_profile_updates": {},
                "relationship_changes": {},
                "context_for_satsuru": {},
                "emotional_state": {}
            }

    async def _apply_updates(self, analysis: Dict[str, Any]):
        """
        分析結果を各JSONファイルに即座に反映
        - 次の会話で活用できるようにする
        """
        # 1. User Profile更新
        if analysis.get('user_profile_updates'):
            updates = analysis['user_profile_updates']
            for key, value in updates.items():
                if isinstance(value, list):
                    # Append to existing list
                    existing = self.user_profile.get(key, [])
                    for item in value:
                        if item not in existing:
                            existing.append(item)
                    self.user_profile[key] = existing
                else:
                    # Replace value
                    self.user_profile[key] = value

            self._save_user_profile()
            print(f"[UPDATE] User profile updated")

        # 2. Relationship Parameters更新
        if analysis.get('relationship_changes'):
            changes = analysis['relationship_changes']
            self.relationship_manager.update_parameters(
                affection_delta=changes.get('affection_delta', 0),
                trust_delta=changes.get('trust_delta', 0),
                intimacy_delta=changes.get('intimacy_delta', 0),
                respect_delta=changes.get('respect_delta', 0)
            )
            print(f"[UPDATE] Relationship parameters updated")
            print(f"[UPDATE] Reasoning: {changes.get('reasoning', 'N/A')}")

        # 3. Context for Satsuru更新
        if analysis.get('context_for_satsuru'):
            self.context_for_satsuru = analysis['context_for_satsuru']
            self._save_context()
            print(f"[UPDATE] Context for satsuru updated")

        # 4. Emotional State更新 (optional, for logging)
        if analysis.get('emotional_state'):
            emotional_state = analysis['emotional_state']
            print(f"[EMOTIONAL] Botan feeling: {emotional_state.get('botan_feeling', 'N/A')}")
            print(f"[EMOTIONAL] Dynamic: {emotional_state.get('relationship_dynamic', 'N/A')}")

    def _load_last_session_time(self) -> float:
        """Load last session end time from file"""
        session_time_file = Path("last_session_time.json")
        if session_time_file.exists():
            try:
                with open(session_time_file, "r") as f:
                    data = json.load(f)
                    return data.get("last_session_end_time", time.time())
            except Exception as e:
                print(f"[SESSION_TIME ERROR] Failed to load: {e}")
                return time.time()
        return time.time()

    def _save_last_session_time(self):
        """Save session end time to file"""
        session_time_file = Path("last_session_time.json")
        try:
            with open(session_time_file, "w") as f:
                json.dump({"last_session_end_time": time.time()}, f)
            print(f"[SESSION_TIME] Saved session end time")
        except Exception as e:
            print(f"[SESSION_TIME ERROR] Failed to save: {e}")

    def calculate_time_elapsed(self) -> Dict[str, Any]:
        """Calculate time elapsed since last session"""
        elapsed_seconds = time.time() - self.last_session_end_time
        elapsed_hours = elapsed_seconds / 3600
        elapsed_days = elapsed_hours / 24

        return {
            "seconds": elapsed_seconds,
            "hours": elapsed_hours,
            "days": elapsed_days,
            "is_first_session_of_day": elapsed_hours > 4,  # More than 4 hours
            "is_long_absence": elapsed_days > 1  # More than 1 day
        }

    def start_idle_thinking_loop(self):
        """Start idle thinking loop as background task"""
        if self.idle_thinking_task is None:
            self.idle_thinking_task = asyncio.create_task(self._idle_thinking_loop())
            print(f"[IDLE_THINKING] Loop started (interval: {self.idle_thinking_interval}s)")

    async def _idle_thinking_loop(self):
        """
        Idle thinking loop - runs continuously in background
        Botan thinks even when no conversation is happening
        """
        while True:
            try:
                # Wait for interval
                await asyncio.sleep(self.idle_thinking_interval)

                # Check if conversation is happening
                time_since_last_conversation = time.time() - self.last_conversation_time

                # If no conversation for interval time, do idle thinking
                if time_since_last_conversation >= self.idle_thinking_interval:
                    print(f"[IDLE_THINKING] Starting idle analysis (no conversation for {time_since_last_conversation/60:.1f} min)")
                    await self._idle_thinking_analysis()
                else:
                    print(f"[IDLE_THINKING] Skipping (recent conversation {time_since_last_conversation:.0f}s ago)")

            except Exception as e:
                print(f"[IDLE_THINKING ERROR] {e}")
                import traceback
                traceback.print_exc()

    async def _idle_thinking_analysis(self):
        """
        Idle thinking analysis - Botan thinks about herself and the user
        Uses 32b CPU LLM for deep reflection
        """
        print(f"[IDLE_THINKING] Starting idle analysis...")

        try:
            start = time.time()

            # Generate idle thinking prompt
            idle_prompt = self._generate_idle_thinking_prompt()

            # Call CPU-only Ollama HTTP API on port 11435
            response = await asyncio.to_thread(
                requests.post,
                "http://localhost:11435/api/chat",
                json={
                    "model": "qwen2.5:32b",
                    "messages": [
                        {"role": "user", "content": idle_prompt}
                    ],
                    "stream": False,
                    "options": {
                        "temperature": 0.7  # More creative for idle thinking
                    }
                },
                timeout=180  # 3 minutes max
            )

            elapsed = time.time() - start

            if response.status_code == 200:
                # Parse result
                result = response.json()
                llm_output = result.get("message", {}).get("content", "")

                analysis = self._parse_idle_thinking(llm_output)

                # Apply updates
                await self._apply_idle_updates(analysis)

                print(f"[IDLE_THINKING] Analysis completed in {elapsed:.2f}s")
            else:
                print(f"[IDLE_THINKING ERROR] Ollama HTTP failed: {response.status_code}")

        except Exception as e:
            print(f"[IDLE_THINKING ERROR] {e}")
            import traceback
            traceback.print_exc()

    def _generate_idle_thinking_prompt(self) -> str:
        """Generate prompt for idle thinking"""
        # Get current relationship status
        rel = self.relationship_manager.get_relationship()

        # Calculate time elapsed
        time_info = self.calculate_time_elapsed()

        return f"""
You are Botan, a 17-year-old gyaru AI character. No one is talking to you right now.
You have some free time to think about yourself and the user (オジサン).

Current relationship status:
- Affection: {rel['affection']}/100
- Trust: {rel['trust']}/100
- Intimacy: {rel['intimacy']}/100
- Respect: {rel['respect']}/100

Time since last session: {time_info['hours']:.1f} hours ({time_info['days']:.1f} days)

What you know about the user:
{json.dumps(self.user_profile, ensure_ascii=False, indent=2)}

Reflect on the following and provide insights in JSON format:

1. self_reflection:
   - current_mood: How do you feel right now? (happy/curious/lonely/content/bored)
   - thoughts: What are you thinking about?
   - feelings_about_user: How do you feel about オジサン?
   - anticipation: Are you looking forward to the next conversation?

2. emotional_changes:
   - mood_shift: Should your mood change based on time elapsed? (e.g., lonely if absent too long)
   - reasoning: Why this change?

3. internal_growth:
   - realizations: Any new understanding about the relationship?
   - questions_for_user: What do you want to ask next time?
   - goals: What do you want to achieve in the relationship?

Return ONLY valid JSON, no extra text:
{{
  "self_reflection": {{}},
  "emotional_changes": {{}},
  "internal_growth": {{}}
}}
"""

    def _parse_idle_thinking(self, llm_output: str) -> Dict[str, Any]:
        """Parse idle thinking LLM output"""
        try:
            analysis = json.loads(llm_output)
            return analysis
        except json.JSONDecodeError as e:
            print(f"[IDLE_THINKING PARSE ERROR] Failed to parse: {e}")
            print(f"[IDLE_THINKING PARSE ERROR] Output was: {llm_output[:500]}")
            return {
                "self_reflection": {},
                "emotional_changes": {},
                "internal_growth": {}
            }

    async def _apply_idle_updates(self, analysis: Dict[str, Any]):
        """Apply updates from idle thinking"""
        # 1. Self reflection (log only)
        if analysis.get('self_reflection'):
            reflection = analysis['self_reflection']
            print(f"[IDLE_REFLECTION] Mood: {reflection.get('current_mood', 'N/A')}")
            print(f"[IDLE_REFLECTION] Thoughts: {reflection.get('thoughts', 'N/A')[:100]}...")

        # 2. Emotional changes (update emotional state if needed)
        if analysis.get('emotional_changes'):
            changes = analysis['emotional_changes']
            mood_shift = changes.get('mood_shift')
            if mood_shift:
                # TODO: Update emotional state file
                print(f"[IDLE_EMOTION] Mood shifted to: {mood_shift}")
                print(f"[IDLE_EMOTION] Reason: {changes.get('reasoning', 'N/A')}")

        # 3. Internal growth (store for future reference)
        if analysis.get('internal_growth'):
            growth = analysis['internal_growth']
            print(f"[IDLE_GROWTH] Realizations: {growth.get('realizations', 'N/A')[:100]}...")
            print(f"[IDLE_GROWTH] Questions: {growth.get('questions_for_user', 'N/A')}")

    def stop_idle_thinking_loop(self):
        """Stop idle thinking loop"""
        if self.idle_thinking_task:
            self.idle_thinking_task.cancel()
            self.idle_thinking_task = None
            print("[IDLE_THINKING] Loop stopped")

        # Save session end time
        self._save_last_session_time()


# Test code
if __name__ == "__main__":
    from relationship_manager import RelationshipManager
    from session_manager import SessionManager

    async def test():
        # Initialize managers
        rel_manager = RelationshipManager(Path("test_relationship.json"))
        sess_manager = SessionManager(Path("test_session.json"))

        # Initialize learning system
        system = RealtimeLearningSystem(
            relationship_manager=rel_manager,
            session_manager=sess_manager,
            user_profile_path=Path("test_user_profile.json"),
            context_path=Path("test_context.json")
        )

        # Simulate conversation
        chat_history = [
            {"role": "system", "content": "You are Botan, a 17-year-old gyaru."}
        ]

        user_msg = "今日は寿司を食べたいな"
        print(f"\nUser: {user_msg}")

        # Get immediate response (GPU 14b, 1.5秒)
        botan_response = await system.immediate_response_gpu(user_msg, chat_history)
        print(f"Botan (immediate): {botan_response}")

        # Background analysis is running (CPU 32b, 60-120秒)
        print("\n[INFO] Background analysis is running...")
        print("[INFO] You can continue chatting without waiting!")

        # Wait for background tasks to complete (for testing)
        print("[INFO] Waiting for CPU 32b analysis to complete (may take 60-120s)...")
        await asyncio.sleep(120)

        print("\n[TEST] Checking updates...")
        print(f"User profile: {system.user_profile}")
        print(f"Relationship: {rel_manager.get_summary()}")

        # Cleanup
        Path("test_relationship.json").unlink(missing_ok=True)
        Path("test_session.json").unlink(missing_ok=True)
        Path("test_user_profile.json").unlink(missing_ok=True)
        Path("test_context.json").unlink(missing_ok=True)

    asyncio.run(test())
