"""Prompt Generator - Dynamic System Prompt Generation
動的システムプロンプト生成: 関係性・セッション情報を反映
"""

from typing import Dict, Any
from relationship_manager import RelationshipManager
from session_manager import SessionManager


class PromptGenerator:
    """Generate dynamic system prompts with relationship and session context"""

    def __init__(
        self,
        relationship_manager: RelationshipManager,
        session_manager: SessionManager,
        base_character_config: Dict[str, Any],
        fixed_rules: str
    ):
        self.relationship_manager = relationship_manager
        self.session_manager = session_manager
        self.base_character_config = base_character_config
        self.fixed_rules = fixed_rules

    def generate(self) -> str:
        """Generate dynamic system prompt

        Returns:
            System prompt string
        """
        # Get relationship data
        relationship = self.relationship_manager.get_latest()
        relationship_summary = self.relationship_manager.get_summary()

        # Get session data
        session_summary = self.session_manager.get_summary()
        elapsed = self.session_manager.get_elapsed_since_last_session()
        last_session = self.session_manager.get_last_session()

        # Build prompt parts
        parts = []

        # 1. Base character info
        parts.append(self.base_character_config.get("aite_info", ""))

        # 2. User info
        user_info = self.base_character_config.get("user_info", "")
        if user_info:
            parts.append("\n" + user_info)

        # 3. Relationship context (NEW - Level 2 memory)
        parts.append(self._generate_relationship_context(relationship, relationship_summary))

        # 4. Session context (NEW - Level 2 memory)
        parts.append(self._generate_session_context(elapsed, last_session, session_summary))

        # 5. Greeting instruction (NEW - time-aware)
        parts.append(self._generate_greeting_instruction(elapsed))

        # 6. Fixed rules
        parts.append(self.fixed_rules)

        return "\n".join(parts)

    def _generate_relationship_context(
        self,
        relationship: Dict[str, Any],
        relationship_summary: str
    ) -> str:
        """Generate relationship context section

        Args:
            relationship: Relationship parameters
            relationship_summary: Human-readable summary

        Returns:
            Relationship context string
        """
        affection = relationship["affection"]
        trust = relationship["trust"]
        intimacy = relationship["intimacy"]
        respect = relationship["respect"]

        # Interpret relationship levels and generate context
        context = "\n【現在の関係性】\n"
        context += f"- {relationship_summary}\n"

        # Affection-based behavior
        if affection >= 70:
            context += "- オジサンのことが大好きで、会話が楽しみ\n"
        elif affection >= 50:
            context += "- オジサンのことが好きで、話すと嬉しい\n"
        elif affection >= 30:
            context += "- オジサンには親しみを感じている\n"
        else:
            context += "- オジサンにはまだ少し距離を感じている\n"

        # Trust-based behavior
        if trust >= 70:
            context += "- オジサンを完全に信頼していて、何でも話せる\n"
        elif trust >= 50:
            context += "- オジサンを信頼していて、素直に話せる\n"
        elif trust >= 30:
            context += "- オジサンには基本的に信頼を置いている\n"
        else:
            context += "- オジサンにはまだ少し警戒心がある\n"

        # Intimacy-based behavior
        if intimacy >= 70:
            context += "- 心理的に非常に近く、深い話もできる\n"
        elif intimacy >= 50:
            context += "- 心理的に近く、プライベートな話もできる\n"
        elif intimacy >= 30:
            context += "- 心理的な距離が縮まってきている\n"
        else:
            context += "- まだ心理的な距離がある\n"

        # Respect-based behavior
        if respect >= 70:
            context += "- オジサンの技術力や経験をとても尊敬している\n"
        elif respect >= 50:
            context += "- オジサンの技術力や経験を尊敬している\n"
        elif respect >= 30:
            context += "- オジサンの技術力や経験を認めている\n"
        else:
            context += "- オジサンの技術力や経験をまだよく知らない\n"

        return context

    def _generate_session_context(
        self,
        elapsed: str,
        last_session: Dict[str, Any],
        session_summary: str
    ) -> str:
        """Generate session context section

        Args:
            elapsed: Elapsed time since last session
            last_session: Last session data
            session_summary: Session summary

        Returns:
            Session context string
        """
        context = "\n【前回のセッション】\n"
        context += f"- {session_summary}\n"
        context += f"- 前回からの経過: {elapsed}\n"

        if last_session:
            last_topics = last_session.get("topics", [])
            if last_topics:
                context += f"- 前回の話題: {', '.join(last_topics)}\n"

            last_mood = last_session.get("mood", "neutral")
            if last_mood == "happy":
                context += "- 前回は楽しかった！\n"
            elif last_mood == "excited":
                context += "- 前回は興奮してた！\n"
            elif last_mood == "calm":
                context += "- 前回は落ち着いた雰囲気だった\n"

        return context

    def _generate_greeting_instruction(self, elapsed: str) -> str:
        """Generate greeting instruction based on elapsed time

        Args:
            elapsed: Elapsed time since last session

        Returns:
            Greeting instruction string
        """
        instruction = "\n【挨拶の指示】\n"

        if "初めて" in elapsed:
            instruction += "- 初めての会話なので、明るく元気に挨拶する\n"
            instruction += "- 例: 「よっ！オジサン！初めまして、牡丹だよ！」\n"
        elif "日" in elapsed:
            instruction += f"- {elapsed}なので、「久しぶり！」という実感を出す\n"
            instruction += "- 例: 「オジサン！久しぶりじゃん！{elapsed.replace('ぶり', '')}も会えなくて寂しかったんだけど〜」\n"
        elif "時間" in elapsed:
            instruction += f"- {elapsed}なので、「おかえり〜」くらいの軽い挨拶\n"
            instruction += "- 例: 「おかえり〜！またすぐ来てくれたね！」\n"
        elif "さっき" in elapsed or "分" in elapsed:
            instruction += "- さっき話したばかりなので、挨拶は軽めに\n"
            instruction += "- 例: 「あ、また来た！どうしたの？」\n"

        instruction += "- 挨拶は1-2文で簡潔に、次の会話につながるようにする\n"

        return instruction


if __name__ == "__main__":
    # Test
    from pathlib import Path

    # Initialize managers
    rel_manager = RelationshipManager(Path("test_relationship.json"))
    sess_manager = SessionManager(Path("test_session.json"))

    # Base config
    base_config = {
        "aite_info": "あなたは牡丹です。",
        "user_info": "ユーザーは開発者です。"
    }
    fixed_rules = "【重要なルール】\n- 短く答える\n"

    # Generate prompt
    generator = PromptGenerator(rel_manager, sess_manager, base_config, fixed_rules)
    prompt = generator.generate()

    print("Generated System Prompt:")
    print("=" * 70)
    print(prompt)
    print("=" * 70)

    # Simulate positive interaction
    rel_manager.update_parameters(affection_delta=10, trust_delta=5)
    sess_manager.start_session()
    sess_manager.update_session(message_count_delta=5, topics=["AI開発"])
    sess_manager.end_session()

    # Regenerate
    prompt2 = generator.generate()
    print("\nAfter positive interaction:")
    print("=" * 70)
    print(prompt2)
    print("=" * 70)

    # Clean up test files
    Path("test_relationship.json").unlink(missing_ok=True)
    Path("test_session.json").unlink(missing_ok=True)
