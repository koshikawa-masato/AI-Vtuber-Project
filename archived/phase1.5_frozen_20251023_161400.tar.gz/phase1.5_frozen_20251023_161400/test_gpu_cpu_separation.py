"""Test GPU/CPU Separation for Dual LLM Structure

This test verifies:
1. qwen2.5:14b can run on GPU (default)
2. qwen2.5:32b can run on CPU (forced via CUDA_VISIBLE_DEVICES='')
3. Both can run in parallel without blocking
4. Environment variable control works correctly
"""

import asyncio
import subprocess
import time
import os
from datetime import datetime


def test_gpu_execution():
    """Test that 14b model runs on GPU (default behavior)"""
    print("\n" + "=" * 70)
    print("TEST 1: GPU Execution (qwen2.5:14b)")
    print("=" * 70)

    start = time.time()

    try:
        # Run on GPU (default, no CUDA_VISIBLE_DEVICES override)
        result = subprocess.run(
            [
                "ollama",
                "run",
                "qwen2.5:14b",
                "Say 'GPU test successful' in one sentence."
            ],
            capture_output=True,
            text=True,
            timeout=30
        )

        elapsed = time.time() - start

        if result.returncode == 0:
            print(f"✅ GPU execution successful")
            print(f"⏱️  Response time: {elapsed:.2f}s")
            print(f"📝 Response: {result.stdout.strip()[:100]}")
            return True
        else:
            print(f"❌ GPU execution failed")
            print(f"Error: {result.stderr}")
            return False

    except Exception as e:
        print(f"❌ GPU test error: {e}")
        return False


def test_cpu_execution():
    """Test that 32b model runs on CPU (forced via environment variable)"""
    print("\n" + "=" * 70)
    print("TEST 2: CPU Execution (qwen2.5:32b with CUDA_VISIBLE_DEVICES='')")
    print("=" * 70)

    start = time.time()

    try:
        # Force CPU execution
        env = os.environ.copy()
        env['CUDA_VISIBLE_DEVICES'] = ''  # Disable GPU

        result = subprocess.run(
            [
                "ollama",
                "run",
                "qwen2.5:32b",
                "Say 'CPU test successful' in one sentence."
            ],
            capture_output=True,
            text=True,
            timeout=180,  # CPU is slower
            env=env
        )

        elapsed = time.time() - start

        if result.returncode == 0:
            print(f"✅ CPU execution successful")
            print(f"⏱️  Response time: {elapsed:.2f}s")
            print(f"📝 Response: {result.stdout.strip()[:100]}")
            return True
        else:
            print(f"❌ CPU execution failed")
            print(f"Error: {result.stderr}")
            return False

    except Exception as e:
        print(f"❌ CPU test error: {e}")
        return False


async def gpu_task():
    """Async GPU task (simulating mouth)"""
    print("\n[GPU TASK] Starting 14b GPU task...")
    start = time.time()

    result = await asyncio.to_thread(
        subprocess.run,
        [
            "ollama",
            "run",
            "qwen2.5:14b",
            "Say 'Parallel GPU test' in one sentence."
        ],
        capture_output=True,
        text=True,
        timeout=30
    )

    elapsed = time.time() - start

    if result.returncode == 0:
        print(f"[GPU TASK] ✅ Completed in {elapsed:.2f}s")
        print(f"[GPU TASK] Response: {result.stdout.strip()[:100]}")
        return True
    else:
        print(f"[GPU TASK] ❌ Failed: {result.stderr}")
        return False


async def cpu_task():
    """Async CPU task (simulating brain)"""
    print("\n[CPU TASK] Starting 32b CPU task...")
    start = time.time()

    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = ''

    result = await asyncio.to_thread(
        subprocess.run,
        [
            "ollama",
            "run",
            "qwen2.5:32b",
            "Say 'Parallel CPU test' in one sentence."
        ],
        capture_output=True,
        text=True,
        timeout=180,
        env=env
    )

    elapsed = time.time() - start

    if result.returncode == 0:
        print(f"[CPU TASK] ✅ Completed in {elapsed:.2f}s")
        print(f"[CPU TASK] Response: {result.stdout.strip()[:100]}")
        return True
    else:
        print(f"[CPU TASK] ❌ Failed: {result.stderr}")
        return False


async def test_parallel_execution():
    """Test that GPU and CPU tasks can run in parallel"""
    print("\n" + "=" * 70)
    print("TEST 3: Parallel GPU + CPU Execution")
    print("=" * 70)
    print("This test verifies that:")
    print("  - GPU 14b (mouth) responds quickly")
    print("  - CPU 32b (brain) runs in background without blocking")

    start = time.time()

    # Start GPU task first (simulating immediate response)
    gpu_result = await gpu_task()

    # Then start CPU task (simulating background analysis)
    # This should NOT block further GPU tasks
    cpu_task_coro = cpu_task()
    cpu_task_handle = asyncio.create_task(cpu_task_coro)

    print("\n[INFO] GPU task completed, CPU task running in background...")
    print("[INFO] In real usage, user can continue chatting now!")

    # Simulate another GPU task while CPU is still running
    print("\n[INFO] Starting another GPU task (simulating continuous chat)...")
    gpu_result2 = await gpu_task()

    # Wait for CPU task to complete
    print("\n[INFO] Waiting for CPU background task to complete...")
    cpu_result = await cpu_task_handle

    elapsed = time.time() - start

    print("\n" + "=" * 70)
    print("PARALLEL EXECUTION RESULTS")
    print("=" * 70)
    print(f"Total elapsed time: {elapsed:.2f}s")
    print(f"GPU task 1: {'✅ Success' if gpu_result else '❌ Failed'}")
    print(f"GPU task 2: {'✅ Success' if gpu_result2 else '❌ Failed'}")
    print(f"CPU background task: {'✅ Success' if cpu_result else '❌ Failed'}")

    if gpu_result and gpu_result2 and cpu_result:
        print("\n✅ Parallel execution test PASSED")
        print("   - GPU tasks completed without waiting for CPU")
        print("   - CPU task completed successfully in background")
        return True
    else:
        print("\n❌ Parallel execution test FAILED")
        return False


async def run_all_tests():
    """Run all GPU/CPU separation tests"""
    print("\n" + "=" * 70)
    print("GPU/CPU SEPARATION TEST SUITE - Phase 1.5")
    print("=" * 70)
    print(f"Test started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("\nTesting dual LLM structure:")
    print("  - Mouth (口): qwen2.5:14b on GPU (1.5s)")
    print("  - Brain (頭脳): qwen2.5:32b on CPU (60-120s)")

    results = []

    # Test 1: GPU execution
    results.append(("GPU Execution", test_gpu_execution()))

    # Test 2: CPU execution
    results.append(("CPU Execution", test_cpu_execution()))

    # Test 3: Parallel execution
    results.append(("Parallel Execution", await test_parallel_execution()))

    # Summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)

    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:25s} {status}")

    all_passed = all(result for _, result in results)

    print("\n" + "=" * 70)
    if all_passed:
        print("🎉 ALL TESTS PASSED - GPU/CPU separation is working correctly!")
        print("\nNext steps:")
        print("  1. Implement conversation-by-conversation async analysis")
        print("  2. Implement automatic user profile learning")
        print("  3. Implement 'satsuru' ability context analysis")
    else:
        print("⚠️  SOME TESTS FAILED - Please review the errors above")
    print("=" * 70)

    return all_passed


if __name__ == "__main__":
    print("\nIMPORTANT: This test will:")
    print("  - Run qwen2.5:14b on GPU (may take 14s on first run)")
    print("  - Run qwen2.5:32b on CPU (will be slower, 60-120s)")
    print("  - Test parallel execution (may take several minutes)")
    print("\nMake sure both models are available:")
    print("  ollama list | grep qwen2.5")
    print("\n")

    input("Press Enter to start tests...")

    result = asyncio.run(run_all_tests())

    exit(0 if result else 1)
