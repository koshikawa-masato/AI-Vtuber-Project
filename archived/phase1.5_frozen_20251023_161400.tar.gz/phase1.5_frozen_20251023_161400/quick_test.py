#!/usr/bin/env python3
"""Quick test script for mouth_llm (qwen2.5:14b)"""

import sys
import httpx
import json
from pathlib import Path


def load_character_config():
    """Load botan character config"""
    config_dir = Path(__file__).parent.parent / "Style-Bert-VITS2-v2"

    # Load base config
    base_path = config_dir / "character_base.json"
    with open(base_path, encoding="utf-8") as f:
        base_config = json.load(f)

    # Load botan config
    char_path = config_dir / "botan_config.json"
    with open(char_path, encoding="utf-8") as f:
        char_config = json.load(f)

    return base_config, char_config


def build_system_prompt(base_config, char_config):
    """Build system prompt from character config"""
    name = char_config.get("name", "Botan")
    age = char_config.get("age", 17)
    personality = char_config.get("personality_description", "")

    speaking_style = char_config.get("speaking_style", {})
    tone = speaking_style.get("tone", "casual")

    prompt = f"""You are {name}, a {age}-year-old high school gyaru girl.

Personality: {personality}

Speaking style: {tone} tone, use gyaru slang naturally.

Important rules:
- Always respond in Japanese
- Keep responses conversational and natural
- Use gyaru expressions like "マジで", "ヤバ", "～じゃん"
- Be friendly and energetic
- Call the user "オジサン"
- Keep responses short and punchy (1-3 sentences max)
"""
    return prompt


def chat(user_message: str, ollama_url="http://localhost:11434", model="qwen2.5:14b"):
    """Send message to LLM and get response"""
    base_config, char_config = load_character_config()
    system_prompt = build_system_prompt(base_config, char_config)

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message}
    ]

    response = httpx.post(
        f"{ollama_url}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "num_predict": 256
            }
        },
        timeout=30.0
    )

    response.raise_for_status()
    result = response.json()
    return result["message"]["content"]


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 quick_test.py <message>")
        print("Example: python3 quick_test.py 'オジサン、今何してる？'")
        sys.exit(1)

    user_message = " ".join(sys.argv[1:])

    print(f"You: {user_message}")
    response = chat(user_message)
    print(f"Botan: {response}")
