#!/bin/bash

# CPU-only Ollama Server for Brain (頭脳) LLM
# This server runs qwen2.5:32b on CPU for deep background analysis
# Port: 11435 (different from default 11434)

echo "Starting CPU-only Ollama server on port 11435..."
echo "This server will run qwen2.5:32b on CPU for deep analysis"

# Force CPU execution
export CUDA_VISIBLE_DEVICES=''

# Share model storage with system Ollama
export OLLAMA_MODELS=$HOME/.ollama/models

# Start Ollama server on port 11435
OLLAMA_HOST=0.0.0.0:11435 ollama serve
