"""Session Manager - Level 2 Memory System
セッション履歴管理: セッション跨ぎで情報を保持
"""

import json
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime


class SessionManager:
    """Manage session history (Level 2 memory)"""

    def __init__(self, data_file: Path = Path("session_history.json")):
        self.data_file = data_file
        self.sessions: List[Dict[str, Any]] = []
        self.current_session: Dict[str, Any] = {}
        self.load()

    def load(self):
        """Load session history from JSON file"""
        if self.data_file.exists():
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.sessions = data.get("sessions", [])
                print(f"[SESSION] Loaded {len(self.sessions)} sessions")
            except Exception as e:
                print(f"[SESSION ERROR] Failed to load: {e}")
                self.sessions = []
                self._save()
        else:
            print("[SESSION] No existing data, initializing")
            self.sessions = []
            self._save()

    def _save(self):
        """Save session history to JSON file"""
        try:
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump({"sessions": self.sessions}, f, ensure_ascii=False, indent=2)
            print(f"[SESSION] Saved {len(self.sessions)} sessions")
        except Exception as e:
            print(f"[SESSION ERROR] Failed to save: {e}")

    def start_session(self):
        """Start a new session

        Returns:
            Session data
        """
        self.current_session = {
            "session_id": len(self.sessions) + 1,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "message_count": 0,
            "topics": [],
            "mood": "neutral",
            "achievements": []
        }
        print(f"[SESSION] Started session #{self.current_session['session_id']}")
        return self.current_session

    def end_session(self):
        """End current session and save to history

        Returns:
            Session data
        """
        if not self.current_session:
            print("[SESSION] No active session to end")
            return None

        self.current_session["end_time"] = datetime.now().isoformat()
        self.sessions.append(self.current_session)
        self._save()

        print(f"[SESSION] Ended session #{self.current_session['session_id']}: "
              f"{self.current_session['message_count']} messages, "
              f"Topics: {self.current_session['topics']}")

        ended_session = self.current_session
        self.current_session = {}
        return ended_session

    def update_session(
        self,
        message_count_delta: int = 0,
        topics: List[str] = None,
        mood: str = None,
        achievements: List[str] = None
    ):
        """Update current session data

        Args:
            message_count_delta: Increase in message count
            topics: New topics discussed
            mood: Current mood
            achievements: New achievements
        """
        if not self.current_session:
            print("[SESSION] No active session, starting new one")
            self.start_session()

        self.current_session["message_count"] += message_count_delta

        if topics:
            # Add new topics (avoid duplicates)
            for topic in topics:
                if topic not in self.current_session["topics"]:
                    self.current_session["topics"].append(topic)

        if mood:
            self.current_session["mood"] = mood

        if achievements:
            self.current_session["achievements"].extend(achievements)

    def get_last_session(self) -> Dict[str, Any]:
        """Get last session data

        Returns:
            Last session data (or empty dict if none)
        """
        if self.sessions:
            return self.sessions[-1]
        return {}

    def get_session_count(self) -> int:
        """Get total session count

        Returns:
            Total session count
        """
        return len(self.sessions)

    def get_last_session_time(self) -> str:
        """Get last session start time

        Returns:
            ISO format datetime string (or empty if none)
        """
        last_session = self.get_last_session()
        return last_session.get("start_time", "")

    def get_elapsed_since_last_session(self) -> str:
        """Get elapsed time since last session

        Returns:
            Human-readable elapsed time (Japanese)
        """
        last_time_str = self.get_last_session_time()
        if not last_time_str:
            return "初めての会話"

        try:
            last_time = datetime.fromisoformat(last_time_str)
            now = datetime.now()
            delta = now - last_time

            days = delta.days
            hours = delta.seconds // 3600
            minutes = (delta.seconds % 3600) // 60

            if days > 0:
                return f"{days}日{hours}時間ぶり"
            elif hours > 0:
                return f"{hours}時間{minutes}分ぶり"
            elif minutes > 0:
                return f"{minutes}分ぶり"
            else:
                return "さっき話したばかり"

        except Exception as e:
            print(f"[SESSION ERROR] Failed to calculate elapsed time: {e}")
            return "久しぶり"

    def get_summary(self) -> str:
        """Get summary of session history

        Returns:
            Summary string (Japanese)
        """
        total_sessions = len(self.sessions)
        if total_sessions == 0:
            return "まだセッションがありません"

        total_messages = sum(s.get("message_count", 0) for s in self.sessions)
        last_session = self.get_last_session()
        last_topics = last_session.get("topics", [])
        elapsed = self.get_elapsed_since_last_session()

        return f"総セッション数: {total_sessions}, " \
               f"総メッセージ数: {total_messages}, " \
               f"前回: {elapsed}, " \
               f"前回のトピック: {', '.join(last_topics) if last_topics else 'なし'}"


if __name__ == "__main__":
    # Test
    manager = SessionManager()
    print("Initial:", manager.get_summary())

    # Simulate session
    manager.start_session()
    manager.update_session(message_count_delta=5, topics=["AI開発", "音声合成"])
    manager.end_session()

    print("After session 1:", manager.get_summary())

    # Start another session
    manager.start_session()
    manager.update_session(message_count_delta=3, topics=["関係性システム"])
    manager.end_session()

    print("After session 2:", manager.get_summary())
    print("Elapsed:", manager.get_elapsed_since_last_session())
