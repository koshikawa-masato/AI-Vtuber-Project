"""Relationship Manager - Level 2 Memory System
関係性永続化システム: 4軸パラメータの管理

affection (好感度): ユーザーへの好意、愛着
trust (信頼度): ユーザーへの信頼
intimacy (親密度): 心理的な距離の近さ
respect (尊敬度): ユーザーへの尊敬の念
"""

import json
from pathlib import Path
from typing import Dict, Any
from datetime import datetime


class RelationshipManager:
    """Manage relationship parameters (Level 2 memory)"""

    def __init__(self, data_file: Path = Path("relationship_parameters.json")):
        self.data_file = data_file
        self.parameters = {
            "affection": 30,   # 好感度: 初期値30（親戚なので最低限の好意）
            "trust": 25,       # 信頼度: 初期値25（まだ知り合って間もない）
            "intimacy": 10,    # 親密度: 初期値10（距離感あり）
            "respect": 30,     # 尊敬度: 初期値30（開発者として尊敬）
            "last_updated": datetime.now().isoformat()
        }
        self.load()

    def load(self):
        """Load relationship parameters from JSON file"""
        if self.data_file.exists():
            try:
                with open(self.data_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    # Preserve existing values, set defaults for missing keys
                    self.parameters["affection"] = data.get("affection", 30)
                    self.parameters["trust"] = data.get("trust", 25)
                    self.parameters["intimacy"] = data.get("intimacy", 10)
                    self.parameters["respect"] = data.get("respect", 30)
                    self.parameters["last_updated"] = data.get("last_updated", datetime.now().isoformat())
                print(f"[RELATIONSHIP] Loaded: Affection {self.parameters['affection']}, "
                      f"Trust {self.parameters['trust']}, "
                      f"Intimacy {self.parameters['intimacy']}, "
                      f"Respect {self.parameters['respect']}")
            except Exception as e:
                print(f"[RELATIONSHIP ERROR] Failed to load: {e}")
                self._save()  # Save defaults
        else:
            print("[RELATIONSHIP] No existing data, initializing with defaults")
            self._save()

    def _save(self):
        """Save relationship parameters to JSON file"""
        try:
            self.parameters["last_updated"] = datetime.now().isoformat()
            with open(self.data_file, "w", encoding="utf-8") as f:
                json.dump(self.parameters, f, ensure_ascii=False, indent=2)
            print(f"[RELATIONSHIP] Saved: Affection {self.parameters['affection']}, "
                  f"Trust {self.parameters['trust']}, "
                  f"Intimacy {self.parameters['intimacy']}, "
                  f"Respect {self.parameters['respect']}")
        except Exception as e:
            print(f"[RELATIONSHIP ERROR] Failed to save: {e}")

    def update_parameters(
        self,
        affection_delta: int = 0,
        trust_delta: int = 0,
        intimacy_delta: int = 0,
        respect_delta: int = 0
    ) -> Dict[str, int]:
        """Update relationship parameters

        Args:
            affection_delta: Change in affection (好感度)
            trust_delta: Change in trust (信頼度)
            intimacy_delta: Change in intimacy (親密度)
            respect_delta: Change in respect (尊敬度)

        Returns:
            Updated parameters
        """
        self.parameters["affection"] = max(0, min(100, self.parameters["affection"] + affection_delta))
        self.parameters["trust"] = max(0, min(100, self.parameters["trust"] + trust_delta))
        self.parameters["intimacy"] = max(0, min(100, self.parameters["intimacy"] + intimacy_delta))
        self.parameters["respect"] = max(0, min(100, self.parameters["respect"] + respect_delta))

        self._save()

        return self.get_latest()

    def get_latest(self) -> Dict[str, Any]:
        """Get current relationship parameters

        Returns:
            Current parameters
        """
        return {
            "affection": self.parameters["affection"],
            "trust": self.parameters["trust"],
            "intimacy": self.parameters["intimacy"],
            "respect": self.parameters["respect"],
            "last_updated": self.parameters["last_updated"]
        }

    def get_summary(self) -> str:
        """Get human-readable summary of relationship

        Returns:
            Summary string (Japanese)
        """
        affection = self.parameters["affection"]
        trust = self.parameters["trust"]
        intimacy = self.parameters["intimacy"]
        respect = self.parameters["respect"]

        # Affection level
        if affection >= 80:
            affection_str = "大好き"
        elif affection >= 60:
            affection_str = "好き"
        elif affection >= 40:
            affection_str = "まあまあ好き"
        elif affection >= 20:
            affection_str = "普通"
        else:
            affection_str = "微妙"

        # Trust level
        if trust >= 80:
            trust_str = "完全に信頼"
        elif trust >= 60:
            trust_str = "信頼"
        elif trust >= 40:
            trust_str = "まあまあ信頼"
        elif trust >= 20:
            trust_str = "少し信頼"
        else:
            trust_str = "信頼してない"

        # Intimacy level
        if intimacy >= 80:
            intimacy_str = "とても親しい"
        elif intimacy >= 60:
            intimacy_str = "親しい"
        elif intimacy >= 40:
            intimacy_str = "まあまあ親しい"
        elif intimacy >= 20:
            intimacy_str = "少し親しい"
        else:
            intimacy_str = "距離感あり"

        # Respect level
        if respect >= 80:
            respect_str = "とても尊敬"
        elif respect >= 60:
            respect_str = "尊敬"
        elif respect >= 40:
            respect_str = "まあまあ尊敬"
        elif respect >= 20:
            respect_str = "少し尊敬"
        else:
            respect_str = "尊敬してない"

        return f"好感度: {affection_str} ({affection}), " \
               f"信頼度: {trust_str} ({trust}), " \
               f"親密度: {intimacy_str} ({intimacy}), " \
               f"尊敬度: {respect_str} ({respect})"


if __name__ == "__main__":
    # Test
    manager = RelationshipManager()
    print("Initial:", manager.get_summary())

    # Simulate positive interaction
    manager.update_parameters(affection_delta=5, trust_delta=3, intimacy_delta=2, respect_delta=1)
    print("After positive interaction:", manager.get_summary())

    # Check persistence
    manager2 = RelationshipManager()
    print("Reload:", manager2.get_summary())
