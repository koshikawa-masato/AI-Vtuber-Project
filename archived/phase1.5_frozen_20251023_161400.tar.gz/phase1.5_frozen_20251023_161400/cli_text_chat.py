#!/usr/bin/env python3
"""
Simple Text-based CLI Chat Client
TTS-free version for faster development iteration
"""

import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

import httpx


class SimpleTextChatClient:
    def __init__(
        self,
        ollama_url: str = "http://localhost:11434",
        model: str = "qwen2.5:14b",
        character: str = "botan"
    ):
        self.ollama_url = ollama_url
        self.model = model
        self.character = character
        self.history = []

        # Load character config
        self.config_dir = Path(__file__).parent.parent / "Style-Bert-VITS2-v2"
        self.load_character_config()

    def load_character_config(self):
        """Load character configuration"""
        try:
            # Load base config
            base_path = self.config_dir / "character_base.json"
            if base_path.exists():
                with open(base_path, encoding="utf-8") as f:
                    self.base_config = json.load(f)
            else:
                print(f"[WARNING] character_base.json not found at {base_path}")
                self.base_config = {}

            # Load character-specific config
            char_path = self.config_dir / f"{self.character}_config.json"
            if char_path.exists():
                with open(char_path, encoding="utf-8") as f:
                    self.char_config = json.load(f)
            else:
                print(f"[WARNING] {self.character}_config.json not found at {char_path}")
                self.char_config = {}

            print(f"[INFO] Character config loaded: {self.character}")

        except Exception as e:
            print(f"[ERROR] Failed to load character config: {e}")
            self.base_config = {}
            self.char_config = {}

    def build_system_prompt(self) -> str:
        """Build system prompt from character config"""
        # Basic character info
        name = self.char_config.get("name", "Botan")
        age = self.char_config.get("age", 17)
        personality = self.char_config.get("personality_description", "")

        # Speaking style
        speaking_style = self.char_config.get("speaking_style", {})
        tone = speaking_style.get("tone", "casual")

        # Greeting pattern (first one)
        greetings = self.char_config.get("greeting_patterns", [])
        greeting_example = greetings[0] if greetings else ""

        prompt = f"""You are {name}, a {age}-year-old high school gyaru girl.

Personality: {personality}

Speaking style: {tone} tone, use gyaru slang naturally.

Example greeting: {greeting_example}

Important rules:
- Always respond in Japanese
- Keep responses conversational and natural
- Use gyaru expressions like "マジで", "ヤバ", "～じゃん"
- Be friendly and energetic
- Call the user "オジサン"
"""
        return prompt

    async def chat(self, user_message: str) -> str:
        """Send message to LLM and get response"""
        # Add user message to history
        self.history.append({
            "role": "user",
            "content": user_message
        })

        # Build messages
        messages = [
            {"role": "system", "content": self.build_system_prompt()}
        ] + self.history

        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    f"{self.ollama_url}/api/chat",
                    json={
                        "model": self.model,
                        "messages": messages,
                        "stream": False,
                        "options": {
                            "temperature": 0.7,
                            "num_predict": 512
                        }
                    }
                )
                response.raise_for_status()
                result = response.json()

                assistant_message = result["message"]["content"]

                # Add to history
                self.history.append({
                    "role": "assistant",
                    "content": assistant_message
                })

                return assistant_message

        except Exception as e:
            return f"[ERROR] Failed to get response: {e}"

    async def run(self):
        """Run interactive chat loop"""
        print("\n" + "="*60)
        print("Simple Text Chat Client (TTS-free)")
        print(f"Model: {self.model}")
        print(f"Character: {self.character}")
        print("="*60)
        print("\nCommands:")
        print("  /quit - Exit chat")
        print("  /clear - Clear history")
        print("="*60 + "\n")

        while True:
            try:
                # Get user input
                user_input = input("\nYou: ").strip()

                if not user_input:
                    continue

                # Handle commands
                if user_input == "/quit":
                    print("\n[INFO] Goodbye!")
                    break

                if user_input == "/clear":
                    self.history = []
                    print("\n[INFO] History cleared")
                    continue

                # Get response
                print("\nBotan: ", end="", flush=True)
                response = await self.chat(user_input)
                print(response)

            except KeyboardInterrupt:
                print("\n\n[INFO] Interrupted. Goodbye!")
                break
            except Exception as e:
                print(f"\n[ERROR] {e}")


async def main():
    """Main entry point"""
    client = SimpleTextChatClient()
    await client.run()


if __name__ == "__main__":
    asyncio.run(main())
